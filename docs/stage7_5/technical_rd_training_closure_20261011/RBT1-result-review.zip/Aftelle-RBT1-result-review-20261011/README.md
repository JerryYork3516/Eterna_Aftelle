# RBT-1 sole execution: small readonly result package

## Review only these two questions

1. Does saved source/result evidence locate a concrete execution or evaluation error capable of changing this trial verdict? Poor results alone do not establish a bug.
2. Does saved evidence distinguish failure to acquire FIT ability from successful FIT ability that failed on CHECK? Final full-FIT predictions/evaluation were not saved. Mark that distinction UNVERIFIED; do not rerun anything to fill it.

## Actual result

REJECT_RBT1_MECHANISM_PILOT. Short 5/20 (requires 19/20), weak-short 0/10 (requires 10/10), long 6/20 (requires 19/20), long activity 1069/4478 (requires >=90%). n_BE=0.9964888095855713; tau=null.
200 updates /1600 triple visits /4800 arm forwards. Final checkpoint SHA aaa40bd8d33df0024ea23dbdd0c838d6935ca70b66eb590534ee7d71ec83736b, 24329 bytes. Checkpoint payload is excluded.
Owner actual tool exit0 (chunk d483a4/session51526), actual driver wait0, native wait0/312 requests/double EOF. Whole93.28557225s. Sampled aggregate RSS1032634368 bytes; continuous peak not proven. Exit0 means technical completion, not mechanism success.

## Contents and use

- protocol/ARMED: exact execution control bytes. protocol/CLOSED: permissions revoked after completion. Different closed hashes are not an execution-time change.
- source/: actual frozen source copies, suffix .txt; no scripts are executed by packaging.
- execution/updates.jsonl: all200 saved logs. Risk is the current batch before its update, not final full-FIT loss.
- execution/check-completion.json and pipeline-result.json: all40 CHECK event results and aggregate complete denominators.
- CHECK/: all120 original saved probability/source rows/resets records,40 source truth interval records,40 construction/identity metadata files. Format is documented in record-index.json and raw_record() source. These binary records contain NO audio, features160, J40, H or weights.
- protocol/actual-code-and-asset-identity.json: exact246-asset executed identity map. Source copies included are checked against it. Omitted public WAV, weights, native executable/library/environment were verified by the original owner, not independently re-read by this publication or external reviewer.
- manifest.json: every payload length/SHA and original path; manifest itself is excluded to avoid circular hashing.

This package does not include final FIT probabilities because none were saved. Existing FIT capture files contain source rows and no final probability payload; initial zero-delta identity checks and batch losses cannot substitute final FIT mechanism evaluation.
No new DSP/model/optimizer/capture/threshold/Gate/Runtime/recording/playback. DEV, grid, Runtime and all current experiment permissions remain false. Test3 stays BLOCKED. If no concrete error is found, close this RBT-1 combination without more experiments. Further research requires a separate mechanism basis and decision.
